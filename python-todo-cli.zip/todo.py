#!/usr/bin/env python3
"""
Todo CLI - a simple command-line task manager.

Usage:
    python3 todo.py add "Task description" [--priority {low,medium,high}] [--due YYYY-MM-DD]
    python3 todo.py list [--all]
    python3 todo.py done <task_id>
    python3 todo.py remove <task_id>
"""

import argparse
import json
import sys
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional

DATA_FILE = Path(__file__).parent / "tasks.json"


@dataclass
class Task:
    id: int
    description: str
    priority: str = "medium"
    due: Optional[str] = None
    done: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))


def load_tasks() -> List[Task]:
    if not DATA_FILE.exists():
        return []
    with DATA_FILE.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return [Task(**item) for item in raw]


def save_tasks(tasks: List[Task]) -> None:
    with DATA_FILE.open("w", encoding="utf-8") as f:
        json.dump([asdict(t) for t in tasks], f, indent=2)


def next_id(tasks: List[Task]) -> int:
    return max((t.id for t in tasks), default=0) + 1


def cmd_add(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    task = Task(
        id=next_id(tasks),
        description=args.description,
        priority=args.priority,
        due=args.due,
    )
    tasks.append(task)
    save_tasks(tasks)
    print(f"Added task #{task.id}: {task.description}")


def cmd_list(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    if not args.all:
        tasks = [t for t in tasks if not t.done]
    if not tasks:
        print("No tasks found.")
        return
    for t in sorted(tasks, key=lambda x: (x.done, {"high": 0, "medium": 1, "low": 2}.get(x.priority, 1))):
        status = "x" if t.done else " "
        due = f" (due {t.due})" if t.due else ""
        print(f"[{status}] #{t.id} [{t.priority}] {t.description}{due}")


def cmd_done(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    for t in tasks:
        if t.id == args.task_id:
            t.done = True
            save_tasks(tasks)
            print(f"Marked task #{t.id} as done.")
            return
    print(f"Task #{args.task_id} not found.", file=sys.stderr)
    sys.exit(1)


def cmd_remove(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    filtered = [t for t in tasks if t.id != args.task_id]
    if len(filtered) == len(tasks):
        print(f"Task #{args.task_id} not found.", file=sys.stderr)
        sys.exit(1)
    save_tasks(filtered)
    print(f"Removed task #{args.task_id}.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="A simple command-line task manager.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_add = sub.add_parser("add", help="Add a new task")
    p_add.add_argument("description")
    p_add.add_argument("--priority", choices=["low", "medium", "high"], default="medium")
    p_add.add_argument("--due", help="Due date, e.g. 2026-07-10")
    p_add.set_defaults(func=cmd_add)

    p_list = sub.add_parser("list", help="List tasks")
    p_list.add_argument("--all", action="store_true", help="Include completed tasks")
    p_list.set_defaults(func=cmd_list)

    p_done = sub.add_parser("done", help="Mark a task as complete")
    p_done.add_argument("task_id", type=int)
    p_done.set_defaults(func=cmd_done)

    p_remove = sub.add_parser("remove", help="Delete a task")
    p_remove.add_argument("task_id", type=int)
    p_remove.set_defaults(func=cmd_remove)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
