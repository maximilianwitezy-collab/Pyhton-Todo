import importlib
import sys
from pathlib import Path

import pytest


@pytest.fixture
def todo_module(tmp_path, monkeypatch):
    sys.path.insert(0, str(Path(__file__).parent.parent))
    import todo
    importlib.reload(todo)
    monkeypatch.setattr(todo, "DATA_FILE", tmp_path / "tasks.json")
    return todo


def test_add_and_list(todo_module):
    args = todo_module.build_parser().parse_args(["add", "Buy milk", "--priority", "high"])
    args.func(args)
    tasks = todo_module.load_tasks()
    assert len(tasks) == 1
    assert tasks[0].description == "Buy milk"
    assert tasks[0].priority == "high"


def test_done(todo_module):
    add_args = todo_module.build_parser().parse_args(["add", "Task 1"])
    add_args.func(add_args)
    done_args = todo_module.build_parser().parse_args(["done", "1"])
    done_args.func(done_args)
    tasks = todo_module.load_tasks()
    assert tasks[0].done is True


def test_remove(todo_module):
    add_args = todo_module.build_parser().parse_args(["add", "Task 1"])
    add_args.func(add_args)
    remove_args = todo_module.build_parser().parse_args(["remove", "1"])
    remove_args.func(remove_args)
    tasks = todo_module.load_tasks()
    assert len(tasks) == 0
