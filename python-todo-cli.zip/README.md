# Todo CLI

A lightweight command-line task manager built with Python's standard library.
Add, list, complete, and delete tasks, with data persisted locally as JSON.

## Features
- Add tasks with priority levels and optional due dates
- List pending or all tasks, sorted by priority
- Mark tasks complete
- Delete tasks
- Zero external dependencies (Python 3.8+)

## Installation
```bash
git clone https://github.com/<you>/todo-cli.git
cd todo-cli
python3 todo.py --help
```

## Usage
```bash
python3 todo.py add "Write portfolio README" --priority high --due 2026-07-10
python3 todo.py list
python3 todo.py done 1
python3 todo.py remove 2
```

## Running tests
```bash
pip install -r requirements-dev.txt
pytest
```

## Project structure
```
todo-cli/
├── todo.py
├── tests/
│   └── test_todo.py
├── requirements-dev.txt
├── LICENSE
└── README.md
```

## License
MIT
